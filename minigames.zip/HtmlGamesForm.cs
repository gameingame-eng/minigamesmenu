using System;
using System.IO;
using System.Windows.Forms;
using Microsoft.Web.WebView2.WinForms;

namespace MinigameMenu
{
    public class HtmlGameForm : Form
    {
        private readonly WebView2 webView;
        private MiniServer? server;
        private readonly string gameFolder;

        public HtmlGameForm(string gameFolder)
        {
            this.gameFolder = gameFolder;

            Text = "HTML Game";
            Width = 1024;
            Height = 768;
            StartPosition = FormStartPosition.CenterScreen;

            webView = new WebView2
            {
                Dock = DockStyle.Fill
            };
            Controls.Add(webView);

            // Load game once the form is shown
            Shown += async (_, __) => await LoadGameAsync();
        }

        private async System.Threading.Tasks.Task LoadGameAsync()
        {
            try
            {
                string rootPath = Path.Combine(Application.StartupPath, gameFolder);

                if (!Directory.Exists(rootPath))
                {
                    MessageBox.Show("Game folder not found: " + rootPath);
                    Close();
                    return;
                }

                // Start local server
                server = new MiniServer(rootPath);
                int port = server.Start();

                await webView.EnsureCoreWebView2Async();
                webView.Source = new Uri($"http://localhost:{port}/index.html");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load game: " + ex.Message);
                Close();
            }
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            base.OnFormClosed(e);
            try
            {
                server?.Dispose();
            }
            catch
            {
                // swallow errors on shutdown
            }
        }
    }
}